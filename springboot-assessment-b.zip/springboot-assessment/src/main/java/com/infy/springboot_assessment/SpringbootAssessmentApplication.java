package com.infy.springboot_assessment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAssessmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAssessmentApplication.class, args);
	}

}
