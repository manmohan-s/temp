package com.infy.springboot_assessment.entity;

public enum EmployeeType {
    FULLTIME, PARTTIME
}
